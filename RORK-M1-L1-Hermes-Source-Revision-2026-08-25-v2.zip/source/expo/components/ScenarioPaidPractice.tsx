import { useRouter } from "expo-router";
import { Mic, Square, X } from "lucide-react-native";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, KeyboardAvoidingView, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { M1L1PaidPractice } from "@/components/M1L1PaidPractice";
import { ProductCard, SectionLabel, StatusPill } from "@/components/PaidProductUI";
import { Backdrop, MicControl, PrimaryButton, Reveal, StateDock } from "@/components/ui";
import { voiceForScenario } from "@/constants/personas";
import { DIFFICULTY } from "@/constants/scenarios";
import { C, GUTTER, T, font, radius } from "@/constants/theme";
import { generateDebrief, nextCounterpartTurn } from "@/lib/ai";
import { activeRunRevision } from "@/lib/activeScenarioRunRepository";
import { m1L1CoachNote, m1L1Comparison, type ConvertedLessonConfig } from "@/lib/convertedLesson";
import {
  attachScenarioCoaching,
  attachScenarioCounterpartTurn,
  completeScenarioComparison,
  preserveScenarioAttempt,
  scenarioPracticePresentation,
  scenarioRunForRoute,
  transitionScenarioPracticeRun,
  type PersistedScenarioPracticeRun,
  type ScenarioCounterpartPresentation,
} from "@/lib/scenarioPractice";
import { playSharedScenarioPressure } from "@/lib/scenarioAudio";
import { useDictation } from "@/lib/useDictation";
import { replaySpeech, resetSpeech, speakPilotAudio, useSpeech } from "@/lib/voice";
import { useStore } from "@/providers/store";
import type { Scenario, Turn } from "@/types/convo";
import { SESSION_SCHEMA_VERSION, type SessionRecord } from "@/types/privacy";

interface ScenarioPaidPracticeProps {
  scenario: Scenario;
  requestedRunId?: string;
  convertedLesson?: ConvertedLessonConfig;
  onReturnToDeck?: (runId: string) => void;
  onDiscard?: () => Promise<void>;
  onSafetyExit?: () => void;
}

function turn(id: string, role: Turn["role"], text: string): Turn {
  return { id, role, text };
}

/** Routes only accepted M1 L1 into its isolated authored runtime. */
export function ScenarioPaidPractice(props: ScenarioPaidPracticeProps): React.JSX.Element {
  if (props.convertedLesson && props.requestedRunId && props.onReturnToDeck && props.onDiscard && props.onSafetyExit) {
    return <M1L1PaidPractice requestedRunId={props.requestedRunId} convertedLesson={props.convertedLesson} onReturnToDeck={props.onReturnToDeck} onDiscard={props.onDiscard} onSafetyExit={props.onSafetyExit} />;
  }
  return <SharedScenarioPaidPractice {...props} />;
}

/** Shared non-converted scenario surface; it never defaults to Adam. */
function SharedScenarioPaidPractice({ scenario, requestedRunId, convertedLesson, onReturnToDeck, onDiscard, onSafetyExit }: ScenarioPaidPracticeProps) {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { activeScenarioRun, profile, replaceActiveScenarioRunStrict, upsertSession } = useStore();
  const fallbackVoice = voiceForScenario(scenario, profile?.persona ?? "woman-hope");
  const restored = scenarioRunForRoute(activeScenarioRun, scenario.id);
  const [value, setValue] = useState<PersistedScenarioPracticeRun | null>(
    restored && (!requestedRunId || restored.run.id === requestedRunId) ? restored : null,
  );
  const [draft, setDraft] = useState<string>(() => {
    const seeded = restored?.run;
    if (seeded?.state === "confirm_attempt_transcript") return seeded.attempt?.transcript ?? "";
    if (seeded?.state === "confirm_response_transcript") return seeded.responseAttempt?.transcript ?? "";
    if (seeded?.state === "confirm_retry_transcript") return seeded.retryAttempt?.transcript ?? "";
    return "";
  });
  const valueRef = useRef<PersistedScenarioPracticeRun | null>(value);
  const [busy, setBusy] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [pendingVoiceKind, setPendingVoiceKind] = useState<"opener" | "response" | "retry" | null>(null);
  const [isMicrophonePrepared, setIsMicrophonePrepared] = useState<boolean>(false);
  const dictation = useDictation();
  const speech = useSpeech();
  const cancelDictation = dictation.cancel;

  useEffect(() => () => {
    cancelDictation().catch(() => {});
    resetSpeech().catch(() => {});
  }, [cancelDictation]);

  const persist = useCallback(async (next: PersistedScenarioPracticeRun): Promise<void> => {
    await replaceActiveScenarioRunStrict(next, activeRunRevision(valueRef.current));
    valueRef.current = next;
    setValue(next);
  }, [replaceActiveScenarioRunStrict]);

  const run = value?.run;
  const context = run?.scenarioContext;
  const state = run?.state;
  const pressure = run?.counterpartTurn;
  const counterpartVoice = context?.contextualPersona ?? fallbackVoice;
  const presentation = scenarioPracticePresentation(value);
  const counterpartPresentation = presentation.isAvailable ? presentation.counterpart : undefined;
  const handleClose = useCallback((): void => {
    if (!convertedLesson) {
      router.back();
      return;
    }
    Alert.alert(
      "Leave this rehearsal?",
      "Your lesson progress is saved. Your current rehearsal stays here on this device until you finish or discard it.",
      [
        { text: "Keep practicing", style: "cancel" },
        { text: "Save and leave", onPress: () => router.back() },
        { text: "Discard this rehearsal", style: "destructive", onPress: () => { void onDiscard?.(); } },
      ],
    );
  }, [convertedLesson, onDiscard, router]);
  const difficultyLabel = context ? DIFFICULTY[context.difficulty].label : "";

  const startRecording = useCallback(async (kind: "opener" | "response" | "retry"): Promise<void> => {
    if (!value || speech.phase === "speaking" || speech.phase === "generating") return;
    setDraft("");
    setError("");
    const nextState = kind === "opener" ? "listening_attempt" : kind === "response" ? "listening_response" : "listening_retry";
    await persist(transitionScenarioPracticeRun(value, nextState, Date.now()));
    await dictation.start();
  }, [dictation, persist, speech.phase, value]);

  const beginCapture = useCallback(async (kind: "opener" | "response" | "retry"): Promise<void> => {
    if (convertedLesson && !isMicrophonePrepared) {
      setPendingVoiceKind(kind);
      return;
    }
    await startRecording(kind);
  }, [convertedLesson, isMicrophonePrepared, startRecording]);

  const allowMicrophone = useCallback(async (): Promise<void> => {
    const kind = pendingVoiceKind;
    if (!kind) return;
    const granted = await dictation.requestPermission();
    if (!granted) return;
    setIsMicrophonePrepared(true);
    setPendingVoiceKind(null);
    await startRecording(kind);
  }, [dictation, pendingVoiceKind, startRecording]);

  const openTypedFallback = useCallback(async (): Promise<void> => {
    const kind = pendingVoiceKind;
    setPendingVoiceKind(null);
    if (!kind) return;
    const review = kind === "opener" ? "confirm_attempt_transcript" : kind === "response" ? "confirm_response_transcript" : "confirm_retry_transcript";
    if (value) await persist(transitionScenarioPracticeRun(value, review, Date.now()));
  }, [pendingVoiceKind, persist, value]);

  const stopRecording = useCallback(async (): Promise<void> => {
    if (!value) return;
    const text = await dictation.stop(state === "listening_attempt" ? "opener" : "reply");
    if (text) setDraft(text);
    const review = state === "listening_attempt" ? "confirm_attempt_transcript" : state === "listening_response" ? "confirm_response_transcript" : "confirm_retry_transcript";
    await persist(transitionScenarioPracticeRun(value, review, Date.now()));
  }, [dictation, persist, state, value]);

  const openTypedReview = useCallback(async (review: "confirm_attempt_transcript" | "confirm_response_transcript" | "confirm_retry_transcript"): Promise<void> => {
    if (!value) return;
    await persist(transitionScenarioPracticeRun(value, review, Date.now()));
  }, [persist, value]);

  const confirmOpening = useCallback(async (): Promise<void> => {
    if (!value || !context || draft.trim().length < 2) return;
    setBusy(true);
    setError("");
    const approved = preserveScenarioAttempt(value, "opener", draft, Date.now());
    await persist(approved);
    try {
      const authoredPressure = convertedLesson?.authoredPressureText;
      const result = authoredPressure ? null : await nextCounterpartTurn(
        scenario,
        context.difficulty,
        [turn(approved.run.attempt?.id ?? `${approved.run.id}-opener`, "user", approved.run.attempt?.transcript ?? draft.trim())],
        context.reaction,
        context.objective,
      );
      const pressureText = authoredPressure ?? result?.reply ?? "";
      if (!pressureText) throw new Error("Counterpart pressure is unavailable");
      const withPressure = attachScenarioCounterpartTurn(approved, {
        id: `${approved.run.id}-counterpart-turn-1`,
        text: pressureText,
        source: authoredPressure ? "authored" : "provider",
        semanticVoiceKey: "contextual_counterpart",
        resolvedAudioId: `${approved.run.curriculumVersion}-${approved.run.id}-counterpart-turn-1`,
      }, Date.now());
      setDraft("");
      await persist(transitionScenarioPracticeRun(withPressure, "ready_for_response", Date.now()));
      await playSharedScenarioPressure(withPressure.run.counterpartTurn!, counterpartVoice, speakPilotAudio);
    } catch {
      setError(`${context.counterpartName}'s response did not come through. Your approved transcript is saved.`);
      await persist(transitionScenarioPracticeRun(approved, "network_error", Date.now()));
    } finally {
      setBusy(false);
    }
  }, [context, convertedLesson, counterpartVoice, draft, persist, scenario, value]);

  const confirmResponse = useCallback(async (): Promise<void> => {
    if (!value || !context || !pressure || draft.trim().length < 2) return;
    setBusy(true);
    setError("");
    const approved = preserveScenarioAttempt(value, "response", draft, Date.now());
    await persist(approved);
    try {
      const response = approved.run.responseAttempt?.transcript ?? draft.trim();
      const lessonNote = convertedLesson ? m1L1CoachNote(response) : null;
      const generated = lessonNote ? null : await generateDebrief(scenario, context.difficulty, [
        turn(approved.run.attempt?.id ?? `${approved.run.id}-opener`, "user", approved.run.attempt?.transcript ?? ""),
        turn(pressure.id, "them", pressure.text),
        turn(approved.run.responseAttempt?.id ?? `${approved.run.id}-response`, "user", response),
      ], context.reaction, context.objective);
      const debrief = generated?.debrief;
      const flag = debrief?.flags[0];
      const coached = attachScenarioCoaching(
        approved,
        lessonNote ? `${lessonNote.worked} ${lessonNote.change}` : flag?.quote ? `In “${flag.quote},” ${flag.issue}` : debrief?.headline ?? "",
        lessonNote?.retryDirection ?? flag?.reframe ?? debrief?.nextRep ?? "Answer the same pressure again with one concrete next step.",
        convertedLesson ? "point_proof_move" : "pushback_response",
        Date.now(),
      );
      setDraft("");
      await persist(coached);
    } catch {
      setError("Hope could not finish the feedback. Your approved transcripts are saved.");
      await persist(transitionScenarioPracticeRun(approved, "model_error", Date.now()));
    } finally {
      setBusy(false);
    }
  }, [context, convertedLesson, draft, persist, pressure, scenario, value]);

  const confirmRetry = useCallback(async (): Promise<void> => {
    if (!value || draft.trim().length < 2) return;
    const approved = preserveScenarioAttempt(value, "retry", draft, Date.now());
    const comparedBase = completeScenarioComparison(approved, Date.now());
    const compared = convertedLesson && comparedBase.run.responseAttempt && comparedBase.run.retryAttempt
      ? { ...comparedBase, run: { ...comparedBase.run, comparison: m1L1Comparison(comparedBase.run.responseAttempt.transcript, comparedBase.run.retryAttempt.transcript) } }
      : comparedBase;
    setDraft("");
    await persist(compared);
  }, [convertedLesson, draft, persist, value]);

  const finish = useCallback(async (): Promise<void> => {
    if (!value || !context || !run?.retryAttempt || !pressure) return;
    const completed = transitionScenarioPracticeRun(value, "complete", Date.now());
    await persist(completed);
    const record: SessionRecord = {
      schemaVersion: SESSION_SCHEMA_VERSION,
      id: run.id,
      scenarioId: context.scenarioId,
      title: context.title,
      counterpart: context.counterpartLabel,
      category: context.category,
      difficulty: context.difficulty,
      reaction: context.reaction,
      skillIds: ["pushback_response"],
      turnCount: 4,
      userTurnCount: 3,
      retryCount: 1,
      completed: true,
      startedAt: run.createdAt,
      endedAt: Date.now(),
      contentRetained: false,
    };
    await upsertSession(record);
  }, [context, persist, pressure, run, upsertSession, value]);

  if (!value || !context || !run || !presentation.isAvailable) {
    const unavailableTitle = presentation.isAvailable ? "This scenario run is unavailable." : presentation.title;
    const unavailableBody = presentation.isAvailable ? "Return to Scenarios and start a fresh rehearsal. No generic practice fixture was substituted." : presentation.body;
    return <View style={[styles.root, styles.center]}><Backdrop /><Text style={styles.title}>{unavailableTitle}</Text><Text style={styles.body}>{unavailableBody}</Text><PrimaryButton label="Back to Scenarios" onPress={() => router.replace("/(tabs)/library")} containerStyle={styles.action} /></View>;
  }

  const isListening = state === "listening_attempt" || state === "listening_response" || state === "listening_retry";
  const reviewKind = state === "confirm_attempt_transcript" ? "opening" : state === "confirm_response_transcript" ? "response" : "retry";
  const showReview = state === "confirm_attempt_transcript" || state === "confirm_response_transcript" || state === "confirm_retry_transcript";

  return <View style={styles.root}><Backdrop />
    <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
      <Pressable onPress={handleClose} style={styles.close} accessibilityRole="button" accessibilityLabel="Leave rehearsal"><X size={21} color={C.textSoft} /></Pressable>
      <View style={styles.headerCopy}><Text style={styles.headerTitle}>{context.counterpartName}</Text><Text style={styles.headerMeta}>{context.counterpartRole} · {difficultyLabel}</Text></View><View style={styles.close} />
    </View>
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 150 }]} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <StatusPill label={context.category.toUpperCase()} tone="purple" /><Text style={styles.scenarioTitle}>{context.title}</Text><Text style={styles.context}>{context.situation}</Text>
        <ProductCard style={styles.identityCard}><View><SectionLabel>Counterpart</SectionLabel><Text style={styles.identityValue}>{context.counterpartLabel}</Text></View><View><SectionLabel>Objective</SectionLabel><Text style={styles.identityValue}>{context.objective}</Text></View><View><SectionLabel>Pressure level</SectionLabel><Text style={styles.identityValue}>{difficultyLabel} · {DIFFICULTY[context.difficulty].note}</Text></View></ProductCard>
        {convertedLesson ? <Pressable onPress={onSafetyExit} style={styles.safetyExit} accessibilityRole="button"><Text style={styles.safetyExitText}>This doesn’t feel safe to practice</Text></Pressable> : null}

        {convertedLesson ? <ConversationThread run={run} counterpartName={context.counterpartName} /> : null}
        {pendingVoiceKind ? <ProductCard accent style={styles.permissionCard}><SectionLabel tone={C.purple}>Use your voice for this rehearsal</SectionLabel><Text style={styles.body}>BYSI asks for microphone access only while you’re practicing. You can type this turn instead.</Text>{dictation.status === "denied" ? <><Text style={styles.title}>Microphone access is off</Text><Text style={styles.body}>Turn it on in Settings, or type this turn instead.</Text><PrimaryButton label="Open Settings" onPress={() => void Linking.openSettings()} containerStyle={styles.action} /></> : <PrimaryButton label="Allow microphone" onPress={() => void allowMicrophone()} containerStyle={styles.action} />}<Pressable onPress={() => void openTypedFallback()} style={styles.permissionSecondary}><Text style={styles.permissionSecondaryText}>Type this turn instead</Text></Pressable><Pressable onPress={() => setPendingVoiceKind(null)} style={styles.permissionSecondary}><Text style={styles.permissionSecondaryText}>Back to rehearsal</Text></Pressable></ProductCard> : null}
        {state === "ready_for_attempt" ? <Reveal><Text style={styles.title}>Open the conversation with {context.counterpartName}.</Text><Text style={styles.body}>Say the first thing you want {context.counterpartRole} to hear. You will approve the transcript before {context.counterpartName} responds.</Text><CaptureActions value={draft} onChange={setDraft} onRecord={() => void beginCapture("opener")} onType={() => void openTypedReview("confirm_attempt_transcript")} /></Reveal> : null}
        {isListening ? <View style={styles.listening}><Text style={styles.title}>Recording your {state === "listening_attempt" ? "opening" : state === "listening_response" ? "response" : "retry"}.</Text><MicControl state="listening" level={dictation.level} onPress={() => void stopRecording()} glyph={<Square size={24} color={C.onAccent} fill={C.onAccent} />} accessibilityLabel="Done speaking" /><Text style={styles.body}>Tap when you are done. Nothing advances until you approve the transcript.</Text></View> : null}
        {showReview ? <Reveal><StatusPill label="Transcript review" tone="purple" /><Text style={styles.title}>Approve your {reviewKind}.</Text>{reviewKind !== "opening" && pressure ? <CounterpartCard presentation={counterpartPresentation} /> : null}<TextInput value={draft} onChangeText={setDraft} multiline style={styles.input} accessibilityLabel={`Edit ${reviewKind} transcript`} /><PrimaryButton label="Approve this transcript" disabled={draft.trim().length < 2 || busy} onPress={() => void (reviewKind === "opening" ? confirmOpening() : reviewKind === "response" ? confirmResponse() : confirmRetry())} containerStyle={styles.action} />{busy ? <ActivityIndicator color={C.purple} style={styles.busy} /> : null}</Reveal> : null}
        {state === "ready_for_response" && pressure ? <Reveal><CounterpartCard presentation={counterpartPresentation} />{speech.phase === "speaking" || speech.phase === "generating" ? <Text style={styles.speaking}>{context.counterpartName} is speaking…</Text> : speech.phase === "failed" ? <PrimaryButton label="Try audio again" onPress={() => void replaySpeech()} containerStyle={styles.action} /> : null}<Text style={styles.title}>Respond to the pressure.</Text><CaptureActions value={draft} onChange={setDraft} onRecord={() => void beginCapture("response")} onType={() => void openTypedReview("confirm_response_transcript")} /></Reveal> : null}
        {state === "hope_coaching" && pressure ? <Reveal><StatusPill label="Hope · coaching" tone="purple" /><CounterpartCard presentation={counterpartPresentation} /><ProductCard accent style={styles.coachCard}><SectionLabel tone={C.purple}>Hope noticed</SectionLabel><Text style={styles.body}>{run.coachNote}</Text><SectionLabel tone={C.purple}>Same-moment retry</SectionLabel><Text style={styles.body}>{run.retryInstruction}</Text></ProductCard><PrimaryButton label={`Retry the same ${context.counterpartName} moment`} onPress={async () => { await persist(transitionScenarioPracticeRun(value, "ready_for_retry", Date.now())); await playSharedScenarioPressure(pressure, counterpartVoice, speakPilotAudio); }} containerStyle={styles.action} /></Reveal> : null}
        {state === "ready_for_retry" && pressure ? <Reveal><StatusPill label="Same-moment retry" tone="purple" /><CounterpartCard presentation={counterpartPresentation} /><Text style={styles.title}>Answer the exact same turn again.</Text><Text style={styles.body}>{run.retryInstruction}</Text><CaptureActions value={draft} onChange={setDraft} onRecord={() => void beginCapture("retry")} onType={() => void openTypedReview("confirm_retry_transcript")} /></Reveal> : null}
        {state === "attempt_comparison" && pressure && run.responseAttempt && run.retryAttempt && run.comparison ? <Reveal><StatusPill label="Review · same moment" tone="purple" /><Text style={styles.title}>Compare your two responses.</Text><CounterpartCard presentation={counterpartPresentation} /><Comparison label="First approved response" text={run.responseAttempt.transcript} /><Comparison label="Retry approved response" text={run.retryAttempt.transcript} /><Text style={styles.body}>{run.comparison.text}</Text><PrimaryButton label="Continue" onPress={() => { if (convertedLesson && onReturnToDeck) onReturnToDeck(run.id); else void persist(transitionScenarioPracticeRun(value, "transfer_cue", Date.now())); }} containerStyle={styles.action} /></Reveal> : null}
        {state === "transfer_cue" ? <Reveal><StatusPill label="Hope · wrap-up" tone="purple" /><Text style={styles.title}>Take the clearer wording into the real conversation.</Text><Text style={styles.body}>This completion belongs to {context.title}, with {context.counterpartName} as {context.counterpartRole}. No unrelated practice fixture was used.</Text><PrimaryButton label="Complete scenario" onPress={() => void finish()} containerStyle={styles.action} /></Reveal> : null}
        {state === "complete" ? <Reveal><StatusPill label="Scenario complete" tone="green" /><Text style={styles.title}>{context.title} is complete.</Text><Text style={styles.body}>You practiced one {context.counterpartName} pressure moment twice at {difficultyLabel.toLowerCase()} difficulty.</Text><PrimaryButton label="Back to Scenarios" onPress={() => router.replace("/(tabs)/library")} containerStyle={styles.action} /></Reveal> : null}
        {state === "network_error" || state === "model_error" ? <Reveal><StatusPill label="Saved checkpoint" tone="amber" /><Text style={styles.title}>{error}</Text><PrimaryButton label="Return to this scenario" onPress={() => void persist(transitionScenarioPracticeRun(value, state === "network_error" ? "confirm_attempt_transcript" : "confirm_response_transcript", Date.now()))} containerStyle={styles.action} /></Reveal> : null}
      </ScrollView>
    </KeyboardAvoidingView>
    {busy ? <StateDock bottomInset={insets.bottom}><View style={styles.processing}><ActivityIndicator color={C.purple} /><Text style={styles.body}>{state === "confirm_attempt_transcript" ? `${context.counterpartName} is responding` : "Hope is reviewing your approved words"}</Text></View></StateDock> : null}
  </View>;
}

function ConversationThread({ run, counterpartName }: { run: PersistedScenarioPracticeRun["run"]; counterpartName: string }) {
  const messages = [
    run.attempt ? { id: run.attempt.id, speaker: "You", text: run.attempt.transcript, mine: true } : null,
    run.counterpartTurn ? { id: run.counterpartTurn.id, speaker: counterpartName, text: run.counterpartTurn.text, mine: false } : null,
    run.responseAttempt ? { id: run.responseAttempt.id, speaker: "You", text: run.responseAttempt.transcript, mine: true } : null,
    run.retryAttempt ? { id: run.retryAttempt.id, speaker: "You · retry", text: run.retryAttempt.transcript, mine: true } : null,
  ].filter((message): message is { id: string; speaker: string; text: string; mine: boolean } => Boolean(message));
  if (messages.length === 0) return null;
  return <View style={styles.thread}>{messages.map((message) => <View key={message.id} style={[styles.messageWrap, message.mine ? styles.messageMine : styles.messageTheirs]}><Text style={styles.messageLabel}>{message.speaker}</Text><View style={[styles.messageBubble, message.mine ? styles.bubbleMine : styles.bubbleTheirs]}><Text style={[styles.messageText, message.mine ? styles.messageTextMine : null]}>{message.text}</Text></View></View>)}</View>;
}

function CaptureActions({ value, onChange, onRecord, onType }: { value: string; onChange: (text: string) => void; onRecord: () => void; onType: () => void }) {
  return <View style={styles.capture}><MicControl state="ready" onPress={onRecord} glyph={<Mic size={28} color={C.purple} />} accessibilityLabel="Start recording" /><Text style={styles.or}>OR TYPE AS AN ACCESSIBLE FALLBACK</Text><TextInput value={value} onChangeText={onChange} multiline style={styles.input} /><PrimaryButton label="Review typed transcript" disabled={value.trim().length < 2} onPress={onType} containerStyle={styles.action} /></View>;
}

function CounterpartCard({ presentation }: { presentation?: ScenarioCounterpartPresentation }) {
  if (!presentation) return null;
  return <View accessible accessibilityLabel={presentation.accessibilityLabel}><ProductCard accent style={styles.counterpartCard}><SectionLabel tone={C.purple}>{presentation.name} · {presentation.role}</SectionLabel><Text style={styles.counterpartText}>“{presentation.text}”</Text><Text style={styles.continuityLabel}>{presentation.continuityLabel}</Text></ProductCard></View>;
}

function Comparison({ label, text }: { label: string; text: string }) {
  return <ProductCard style={styles.comparison}><SectionLabel>{label}</SectionLabel><Text style={styles.body}>“{text}”</Text></ProductCard>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg }, flex: { flex: 1 }, center: { alignItems: "center", justifyContent: "center", paddingHorizontal: GUTTER },
  header: { minHeight: 70, paddingHorizontal: GUTTER, paddingBottom: 8, flexDirection: "row", alignItems: "center" }, close: { width: 44, height: 44, alignItems: "center", justifyContent: "center" }, headerCopy: { flex: 1, alignItems: "center" }, headerTitle: { fontFamily: font.bold, fontSize: 17, color: C.text }, headerMeta: { ...T.caption, color: C.purple, marginTop: 2 },
  scroll: { paddingHorizontal: GUTTER, paddingTop: 12 }, safetyExit: { alignSelf: "flex-start", minHeight: 44, justifyContent: "center", marginTop: 8 }, safetyExitText: { ...T.caption, color: C.clay, fontFamily: font.semi }, scenarioTitle: { ...T.title, marginTop: 10 }, context: { ...T.support, marginTop: 7 }, identityCard: { marginTop: 16, gap: 14 }, identityValue: { ...T.support, color: C.text, marginTop: 4 },
  title: { ...T.title, marginTop: 22 }, body: { ...T.support, marginTop: 8 }, action: { marginTop: 18 }, capture: { alignItems: "center", marginTop: 22 }, or: { ...T.caption, marginVertical: 16 }, input: { ...T.body, minHeight: 108, width: "100%", backgroundColor: C.surfaceHigh, borderWidth: 1, borderColor: C.glassEdge, borderRadius: radius.md, padding: 16, textAlignVertical: "top" },
  listening: { alignItems: "center", gap: 20, paddingTop: 36 }, busy: { marginTop: 14 }, speaking: { ...T.caption, color: C.purple, marginTop: 10 }, thread: { marginTop: 16, gap: 12 }, messageWrap: { maxWidth: "84%" }, messageMine: { alignSelf: "flex-end", alignItems: "flex-end" }, messageTheirs: { alignSelf: "flex-start", alignItems: "flex-start" }, messageLabel: { ...T.caption, fontFamily: font.semi, marginBottom: 4 }, messageBubble: { borderRadius: 18, paddingHorizontal: 14, paddingVertical: 11 }, bubbleMine: { backgroundColor: C.purple }, bubbleTheirs: { backgroundColor: C.surfaceHigh, borderWidth: 1, borderColor: C.line }, messageText: { ...T.support, color: C.text }, messageTextMine: { color: C.onAccent }, processing: { minHeight: 56, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 12 }, permissionCard: { marginTop: 16 }, permissionSecondary: { minHeight: 44, alignItems: "center", justifyContent: "center" }, permissionSecondaryText: { ...T.caption, color: C.purple, fontFamily: font.semi }, counterpartCard: { marginTop: 18 }, counterpartText: { ...T.body, marginTop: 10 }, continuityLabel: { ...T.caption, marginTop: 12 }, coachCard: { marginTop: 14, gap: 8 }, comparison: { marginTop: 10 },
});
