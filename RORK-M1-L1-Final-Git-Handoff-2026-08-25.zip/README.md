# RORK M1 L1 Final Git Handoff — 2026-08-25

## Identity and lineage

- Parent commit: `8432d2c269a3d0c76532b8ddaea6bc9eddfd8989`
- Intended branch: `rork/m1-l1-source-acceptance-final`
- Source snapshot identity: `e594bcb5c136c3f8ac36062d2cdff682bbb71fd9ce0631c05ec7db6f13bc384d`
- Embedded patch SHA-256: `a4c71c3eb8e3dc77dbe3567e443b403bd49fd8a0d7099b04380d0df51bd1d748`
- Embedded patch size: `111,259 bytes`

The snapshot identity is the SHA-256 of the exact sorted `SOURCE-MANIFEST.sha256` bytes. The `source/` directory is reconstructed from the parent commit plus the exact embedded binary-capable patch and includes the active backend, Expo, iOS, functions, shared source, and `rork.json`.

## Apply the patch

From a clean clone containing the parent commit:

```sh
git checkout 8432d2c269a3d0c76532b8ddaea6bc9eddfd8989
git switch -c rork/m1-l1-source-acceptance-final
sha256sum rork-m1-l1-final.patch
git apply --check --binary rork-m1-l1-final.patch
git apply --binary rork-m1-l1-final.patch
```

The patch digest must be `a4c71c3eb8e3dc77dbe3567e443b403bd49fd8a0d7099b04380d0df51bd1d748`.

## Verify the packaged snapshot

From the extracted handoff root:

```sh
sha256sum -c SOURCE-MANIFEST.sha256
sha256sum SOURCE-MANIFEST.sha256
sha256sum -c ARTIFACT-MANIFEST.sha256
```

The second command must report `e594bcb5c136c3f8ac36062d2cdff682bbb71fd9ce0631c05ec7db6f13bc384d`.

## Recorded validation

These validations were completed before artifact materialization; they were not rerun while packaging:

```sh
cd expo
bun run test
# 727 pass, 0 fail; 727 tests across 45 files

bun run check
# exit 0; TypeScript and lint passed

bun test __tests__/clientEnvGuard.test.ts
# 4 pass, 0 fail; 4 tests across 1 file

bun run export
# web bundles: 3; iOS bundles: 1; Android bundles: 1; Exported: dist

cd ..
git diff --check
# exit 0
```

Rork static validation command: `runChecks({ appPath: "expo" })`  
Result: success; 0 TypeScript errors, 0 lint errors, 0 project-structure errors.

## ZIP receipt

The final ZIP byte size and SHA-256 are reported with the credential-free delivery URL after archive finalization. A ZIP cannot truthfully contain its own ordinary SHA-256 because writing that digest into `README.md` changes the ZIP bytes and therefore changes the digest. The external receipt is the authoritative checksum for the delivered archive.

## Scope

Environment files, credentials, dependencies, `.git`, generated caches, exports, test output, logs, audio, and transcripts are excluded. Real-device acceptance, lesson fan-out, launch work, and public launch are not claimed or authorized.
